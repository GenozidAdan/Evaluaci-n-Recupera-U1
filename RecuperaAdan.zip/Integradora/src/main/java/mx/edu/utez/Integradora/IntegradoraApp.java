package mx.edu.utez.Integradora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegradoraApp {

	public static void main(String[] args) {
		SpringApplication.run(IntegradoraApp.class, args);
	}

}
